//
//  CALayer+Additions.h
//  VideoProjectI
//
//  Created by Gohar Vardanyan on 8/3/18.
//  Copyright © 2018 Gohar Vardanyan. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

@interface CALayer (Additions)

- (CALayer *)clone;

@end
