//
//  AddStickersCollectionViewCell.h
//  VideoProjectI
//
//  Created by Gohar Vardanyan on 8/7/18.
//  Copyright © 2018 Gohar Vardanyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddStickersCollectionViewCell : UICollectionViewCell

- (void)fillCellWithImage:(UIImageView *)imageView;

@end
