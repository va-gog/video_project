//
//  AddStickersViewController.h
//  VideoProjectI
//
//  Created by Gohar Vardanyan on 8/1/18.
//  Copyright © 2018 Gohar Vardanyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddStickersViewController : UIViewController

@property (nonatomic) NSURL *chosenVideoURL;

@end
