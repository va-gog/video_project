//
//  ChooseVideoViewController.h
//  VideoProjectI
//
//  Created by Gohar Vardanyan on 8/6/18.
//  Copyright © 2018 Gohar Vardanyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChooseVideoViewController : UIViewController

@end
